package com.helicaltech.pcni.process;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.helicaltech.pcni.resourcereader.XMLResourceReader;
import com.helicaltech.pcni.singleton.ApplicationProperties;

/**
 * An instance of this class is typically used once in the web app starting. The
 * object reads the project.properties and takes part in initializing the
 * singleton class ApplicationProperties
 *
 * @author Rajasekhar
 * @since 1.1
 */
public class BaseLoader {

	private static final Logger logger = LoggerFactory.getLogger(BaseLoader.class);

	private String solutionDirectory = null;

	/**
	 * Constructs an instance of this class
	 *
	 * @param properties
	 *            An instance of ApplicationProperties, which is a singleton
	 */
	public BaseLoader(ApplicationProperties properties) {
		
		this.solutionDirectory = properties.getSolutionDirectory();

	}

	public BaseLoader() {		
	}

	/**
	 * Loads the resources from the solution directory
	 *
	 * @return A string which represents a json of all the content of the
	 *         solution directory
	 */
	public String loadResources() {
		String resources = null;
		
		String loadSolutionDirectory = solutionDirectory;
		if (loadSolutionDirectory != null) {
			try {
				XMLResourceReader jrd = new XMLResourceReader();
				jrd.setPath(loadSolutionDirectory);
				resources = jrd.getResources();
			} catch (Exception e) {
				logger.error("ConfigurationException occurred", e);
			}
		} else {
			logger.error("Solution Directory is null");
		}

		return resources;
	}
}

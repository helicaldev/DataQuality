package com.helicaltech.pcni.scheduling;

public interface ICronExpresssionOperation {

	public String convertDateIntoCronExpression(net.sf.json.JSONObject jsonData);
}

package com.helicaltech.pcni.useractions;

import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.helicaltech.pcni.resourceloader.JSONProcessor;
import com.helicaltech.pcni.rules.BusinessRulesUtils;
import com.helicaltech.pcni.rules.JSONUtils;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Abstract class which holds the methods for use by the file operations module.
 * <p/>
 * Created by author on 11-Oct-14.
 *
 * @author Rajasekhar
 * @version 1.0
 * @since 1.1
 */
public abstract class AbstractOperationsHandler {

	private static final Logger logger = LoggerFactory.getLogger(AbstractOperationsHandler.class);

	/**
	 * <p>
	 * Gets efwFolder key value from setting.xml. If it is not present in
	 * setting.xml, it will throw exception else return value of efwFolder node.
	 * </p>
	 *
	 * @return a <code>String</code> which specifies value of efwFolder node in
	 *         setting.xml
	 */
	public String getExtension() {
		return "efwfolder";
	}

	/**
	 * Checks whether the currently logged in user credentials are matching with
	 * the ones present in the fileUnderConcern file parameter
	 *
	 * @param fileUnderConcern
	 *            A <code>File</code> object
	 * @return true if it is valid user else return false.
	 */
	public boolean areUserCredentialsMatching(File fileUnderConcern) {
		List<String> userDetails = BusinessRulesUtils.getUserDetails();
		JSONProcessor processor = new JSONProcessor();
		JSONObject jsonObject = null;
		if (fileUnderConcern.isFile()) {
			jsonObject = processor.getJSON(fileUnderConcern.toString(), false);
		} else {
			jsonObject = processor.getJSON(fileUnderConcern.toString() + File.separator + "index." + getExtension(), false);
		}
		return JSONUtils.verifyUserCredentials(userDetails, jsonObject);
	}

	/**
	 * Checks whether index.efwFolder exists or not in the specified directory
	 *
	 * @param fileUnderConcern
	 *            A <code>File</code> object
	 * @return true if index.efwFolder exist else return false.
	 */
	public boolean isIndexFilePresent(File fileUnderConcern) {
		return new File(fileUnderConcern.toString() + File.separator + "index." + getExtension()).exists();
	}

	/**
	 * <p>
	 * Returns the list of extensions for which setting xml has configuration.
	 * For example efw, efwsr, efwFav, efwFolder etc.
	 * </p>
	 *
	 * @return List of rule attribute.
	 */
	public List<String> getListOfExtensionsFromSettings() {
		List<String> listOfExtensions = new ArrayList<String>();
		listOfExtensions.add("html");
		listOfExtensions.add("rdf");
		listOfExtensions.add("fav");
		listOfExtensions.add("result");
		logger.debug("The list of extensions for which setting xml has configuration : " + listOfExtensions);
		return listOfExtensions;
	}
}

/**
 * Consists of classes related to the loading the resources form the solution directory
 */
package com.helicaltech.pcni.resourceloader;
/**
 * Consists of utility classes with mostly static methods for use by the rest of the code base
 */
package com.helicaltech.pcni.utility;
package com.helicaltech.pcni.rules.interfaces;

/**
 * This is just a marker interface which implies any rule or condition
 *
 * @author Rajasekhar
 * @since 1.1
 */
public interface IRule {

}

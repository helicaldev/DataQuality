package com.helicaltech.pcni.scheduling;

public interface ISchedule {

}

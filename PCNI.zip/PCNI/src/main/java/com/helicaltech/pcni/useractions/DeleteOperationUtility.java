package com.helicaltech.pcni.useractions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.helicaltech.pcni.rules.BusinessRulesFactory;
import com.helicaltech.pcni.rules.interfaces.IDeleteOperation;
import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * This is an utility class for Delete operation. Supports
 * <code>DeleteOperationHandler</code>.
 * </p>
 * Created by author on 16-10-2014.
 *
 * @author Rajasekhar
 * @version 1.0
 * @since 1.1
 */
public class DeleteOperationUtility extends AbstractOperationsHandler {

	private static final Logger logger = LoggerFactory.getLogger(DeleteOperationUtility.class);
	/**
	 * The content of the operations tag
	 */
	private final Map<String, Map<String, String>> operationsTagMap = new IOOperationsUtility().getMapOfOperationSettings();
	/**
	 * The list of file extensions
	 */
	private List<String> listOfFileExtensions;

	/**
	 * Setter for listOfFileExtensions
	 *
	 * @param listOfFileExtensions
	 *            a <code>List</code> of extensions
	 */
	public void setListOfFileExtensions(List<String> listOfFileExtensions) {
		this.listOfFileExtensions = listOfFileExtensions;
	}

	/**
	 * Before physically deleting files and folders, the methods checks whether
	 * all files and folders could be deleted. If yes it will be returning true.
	 *
	 * @param directory
	 *            The directory under concern
	 * @return true if all the files and folders in directory can be deleted
	 */
	public boolean tryDeleting(File directory) {

		if (directory == null || !directory.exists()) {
			logger.error("Directory " + directory + " doesn't exist!");
			return false;
		}

		return trySatisfyingRules(directory);
	}

	/**
	 * <p>
	 * Applies the rules specific to the directory deletion. If the user has no
	 * authority to delete he will not be allowed to delete.
	 * </p>
	 *
	 * @param directory
	 *            The directory under concern
	 * @return true if the credentials are matching
	 */
	private boolean trySatisfyingRules(File directory) {
		if (!isIndexFilePresent(directory) || !areUserCredentialsMatching(directory)) {
			logger.info("Can't delete " + directory + ". Aborting the operation due to insufficient privileges.");
			return false;
		}

		File[] files = directory.listFiles();
		if (files != null) {
			if (!inspect(files)) {
				return false;
			}
		} else {
			logger.debug(directory + " is empty. No conditions for deletion.");
		}
		return true;
	}

	/**
	 * <p>
	 * Applies the file and folder specific deletion rules to files array.
	 * </p>
	 *
	 * @param files
	 *            An array of <code>File</code>s
	 */
	private boolean inspect(File[] files) {
		for (File file : files) {
			if (file.isFile()) {
				logger.debug("Inspecting file "+file);
				if (!trySatisfyingRulesForFile(file)) {
					logger.info("Can't delete the file " + file + ". Aborting the operation.");
					return false;
				}
			} else {
				if (!trySatisfyingRules(file)) {
					logger.info("Can't delete the file " + file + ". Aborting the operation.");
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * <p>
	 * The file is deletable only if its extension has configuration in
	 * setting.xml. File specific deletion rule is applied by this method.
	 * </p>
	 *
	 * @param file
	 *            The file under concern
	 * @return true if the rules are satisfied
	 */
	private boolean trySatisfyingRulesForFile(File file) {
		String[] array = (file.toString().split("\\.(?=[^\\.]+$)"));
		String actualExtension;
		if (array.length >= 2) {
			actualExtension = array[1];
			if (listOfFileExtensions != null && listOfFileExtensions.contains(actualExtension)) {
				return applyFileSpecificRule(file, actualExtension);
			} else {
				logger.debug("File with out extension in Settings. No conditions for deleting. Its extension was " + actualExtension);
			}
		} else {
			logger.debug("File with out any extension. No conditions for deleting.");
			return true;
		}
		return true;
	}

	/**
	 * File specific deletion rule is applied by this method by invoking the
	 * configuration class from setting.xml
	 *
	 * @param file
	 *            a <code>File</code> which specifies the file name that is to
	 *            be deleted
	 * @param actualExtension
	 *            a <code>String</code> which specifies the file extension.
	 * @return true if file is deletable else return false
	 */
	private boolean applyFileSpecificRule(File file, String actualExtension) {
		if (file != null && actualExtension != null) {
			String key = findCorrespondingKey(actualExtension);
			String clazz = findCorrespondingClass(key, "delete");
			logger.debug("key : " + key + " clazz : " + clazz);
			if (key != null && clazz != null) {
				BusinessRulesFactory rulesFactory = new BusinessRulesFactory();
				IDeleteOperation iDeleteOperation = rulesFactory.getBusinessRuleImplementation(clazz);
				return iDeleteOperation.isDeletable(file);
			}
			logger.error("Can't delete the file " + file + ". Aborting the operation.");
		}
		return false;
	}

	/**
	 * <p>
	 * Based on the file key type, the corresponding class from the setting.xml
	 * is returned for that key
	 * </p>
	 *
	 * @param key
	 *            The key for the file extension in setting.xml
	 * @param action
	 *            file operation under concern.
	 * @return a <code>String</code> which specifies the class name.
	 */
	public String findCorrespondingClass(String key, String action) {
		logger.debug("Finding class "+key+" with action "+action+" & operationtagmap: "+operationsTagMap);
		if (operationsTagMap != null && key != null) {
			Map<String, String> map = operationsTagMap.get(key);
			for (Map.Entry<String, String> entry : map.entrySet()) {
				if (action.equalsIgnoreCase(entry.getKey())) {
					return entry.getValue();
				}
			}
		}
		logger.error("Couldn't find the value for key delete. Returning null.");
		return null;
	}

	/**
	 * <p>
	 * Obtains the corresponding key for the file with extension actualExtension
	 * </p>
	 *
	 * @param actualExtension
	 *            a <code>String</code> which is extension of a file
	 * @return The corresponding key for the actualExtension
	 */
	public String findCorrespondingKey(String actualExtension) {
		IOOperationsUtility ioOperationUtility = new IOOperationsUtility();

		Map<String, String> keyValuePairs = ioOperationUtility.getVisibleExtensionsKeyValuePairs();
		if (keyValuePairs != null && actualExtension != null) {
			for (Map.Entry<String, String> entry : keyValuePairs.entrySet()) {
				logger.debug(actualExtension+" Key is getting: "+entry.getKey()+" And Value: "+entry.getValue());
				if (actualExtension.equalsIgnoreCase(entry.getKey())) {
					return entry.getValue();
				}
			}
		}
		logger.error("Couldn't find the value for key {}. Returning null.", actualExtension);
		return null;
	}

	/**
	 * <p>
	 * Deletes the files by invoking the specific classes for the corresponding
	 * files. No conditions are considered for files with no configuration from
	 * setting.xml. They are simply deleted.
	 * <p/>
	 * </p>
	 *
	 * @param file
	 *            a <code>File</code> which has to be deleted.
	 */
	public void deleteFile(File file) {
		String[] array = (file.toString().split("\\.(?=[^\\.]+$)"));
		String actualExtension;
		if (array.length >= 2) {
			actualExtension = array[1];
			if (listOfFileExtensions != null && listOfFileExtensions.contains(actualExtension)) {
				logger.debug("The file has " + file + " has some concerns before deletion");
				clean(file, actualExtension);
			} else {
				if (file.delete()) {
					logger.debug(file + " has no Settings. No conditions for deleting. Deleted.");
				} else {
					logger.debug(file + " couldn't be deleted.");
				}
			}
		} else {
			if (file.delete()) {
				logger.debug(file + " has no extension. No conditions for deleting. Deleted.");
			} else {
				logger.debug(file + " couldn't be deleted.");
			}
		}
	}

	/**
	 * <p>
	 * Delete operation is handled by the specific object which is configured in
	 * setting.xml for the specific type of extension.
	 * </p>
	 *
	 * @param file
	 *            The file under concern
	 * @param actualExtension
	 *            a <code>String</code> which specifies extension of file
	 */
	private void clean(File file, String actualExtension) {
		logger.debug("Cleaning with extnsion : " + actualExtension);
		String key = findCorrespondingKey(actualExtension);
		String clazz = findCorrespondingClass(key, "delete");
		logger.debug("key : " + key + " clazz : " + clazz);
		if (key != null && clazz != null) {
			BusinessRulesFactory rulesFactory = new BusinessRulesFactory();
			/*
			 * Ideally expecting a singleton
			 */
			IDeleteOperation iDeleteOperation = rulesFactory.getBusinessRuleImplementation(clazz);
			logger.debug("Invoking the file specific delete operation handler for file " + file);
			iDeleteOperation.delete(file);
		}
	}

	/**
	 * <p>
	 * Deletes the directories by applying the same rules as that of file
	 * deletion. No conditions are considered for files with no configuration
	 * from setting.xml
	 * </p>
	 *
	 * @param directory
	 *            a <code>File</code> which contains directory name
	 */
	public void deleteDirectory(File directory) {
		logger.info("Trying to delete the directory " + directory);
		if (!directory.exists()) {
			logger.info("Directory {} doesn't exist", directory);
		}
		File[] files = directory.listFiles();
		logger.debug("Checking File list");
		if (files != null) {
			logger.info(directory + " contents : " + Arrays.asList(files));
			for (File file : files) {
				if (file.isFile()) {
					deleteFile(file);
				} else {
					deleteDirectory(file);
				}
			}
			IOOperationsUtility.deleteEmptyDirectoryWithLogs(directory);
		} else {
			logger.info("Directory " + directory + " is empty.");
			IOOperationsUtility.deleteEmptyDirectoryWithLogs(directory);
		}
	}
}

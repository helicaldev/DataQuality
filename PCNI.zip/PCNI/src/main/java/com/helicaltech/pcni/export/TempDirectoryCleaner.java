package com.helicaltech.pcni.export;

import java.io.File;

import com.helicaltech.pcni.singleton.ApplicationProperties;

/**
 * Cleans the System/Temp directory in solution directory
 */
public class TempDirectoryCleaner {
	/**
	 * Returns the System/Temp directory path as a string in solution directory
	 *
	 * @return The location of System/Temp directory
	 */
	public static File getTempDirectory() {
		ApplicationProperties properties = ApplicationProperties.getInstance();
		String strTempDir = properties.getSolutionDirectory() + File.separator + "System" + File.separator + "Temp";
		return new File(strTempDir);
	}
}

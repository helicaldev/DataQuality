/**
 * This package consist of classes which loads the resources 
 *
 */
package com.helicaltech.pcni.resourcereader;